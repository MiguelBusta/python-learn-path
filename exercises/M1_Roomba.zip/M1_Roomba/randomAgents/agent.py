"""
M1 Actividad Roomba
Miguel Ángel Bustamante Pérez A01781583
Juan Muniain Otero A01781341

14/11/2022
"""
from mesa import Agent

class RandomAgent(Agent):
    """
    Agent that moves randomly.
    Attributes:
        unique_id: Agent's ID 
        direction: Randomly chosen direction chosen from one of eight directions
    """
    trash_taken = 0 #initiate the trash collected for each agent
    def __init__(self, unique_id, model):
        """
        Creates a new random agent.
        Args:
            unique_id: The agent's ID
            model: Model reference for the agent
        """
        super().__init__(unique_id, model) #calls the builder from Agent class to create agents in the model
        self.direction = 4 #where the agent is aiming to move
        self.steps_taken = 0 #initiate the steps  

    def get_trash_collected(self):
        return self.trash_taken

    def move(self):
        """ 
        Determines if the agent can move in the direction that was chosen
        """
        possible_steps = self.model.grid.get_neighborhood(
            self.pos,
            moore=True, # Boolean for whether to use Moore neighborhood (including diagonals) or Von Neumann (only up/down/left/right).
            include_center=True) #return a list of cells that surround a certain point 

        
        #check if the roomba has neighbors around it. 
        #usedSpaces = self.model.grid.get_neighbors()

        # Checks which grid cells are empty
        # map() = Returns a list of the results after applying the given function to each item of a given iterable (list, tuple etc.) 
        # freeSpaces = list(map(self.model.grid.is_cell_empty, possible_steps)) #matrix that contains all the free spaces that are around a given point 

        #list that stores the possible spaces 
        possible_spaces = []
        for step in possible_steps:
            # get a list of agents in that step
            cell_list = self.model.grid.get_cell_list_contents(step)
            # if that cell is not empty
            if not self.model.grid.is_cell_empty(step):
                # if the first element from the list is a trash agent 
                if cell_list[0].unique_id == "trash": 
                    possible_spaces.append(True)
                else:
                    possible_spaces.append(False)
            else:
                possible_spaces.append(True)

        # returns a zip object, which is an iterator of tuples where the first item in each passed iterator is paired together, and then the second item in each passed iterator are paired together etc. If the passed iterators have different lengths, the iterator with the least items decides the length of the new iterator.
        next_moves = [p for p,f in zip(possible_steps, possible_spaces) if f == True] #creates a list with all the real possible steps
       
        # Select either a cell with trash, or a random cell
        #next_move = next_moves[0]

        # if next moves has elements (spaces to move)
        if len(next_moves) > 0:
            for move in next_moves:
                #if the cell is not empty
                if not self.model.grid.is_cell_empty(move): 
                    #if the content of that cell is a trash agent 
                    if self.model.grid.get_cell_list_contents(move)[0].unique_id == "trash": 
                        next_move = move
                    break
                else:
                    # if not choose randomly an empty cell
                    next_move = self.random.choice(next_moves)
        else:
            next_move = self.pos

        # Now move:
        if self.random.random() < 0.1:
            self.model.grid.move_agent(self, next_move) #moves that agent to that cell
            self.steps_taken+=1 #increases the steps counter 
            if self.model.grid.get_cell_list_contents(next_move)[0].unique_id == "trash":
                self.model.grid.remove_agent(self.model.grid.get_cell_list_contents(next_move)[0])
                self.trash_taken += 1 
                

    def step(self):
        """ 
        Determines the new direction it will take, and then moves
        """
        # self.direction = self.random.randint(0,8)
        # print(f"Agente: {self.unique_id} movimiento {self.direction}")
        self.move()

class ObstacleAgent(Agent):
    """
    Obstacle agent. Just to add obstacles to the grid.
    """
    def __init__(self, unique_id, model):
        super().__init__(unique_id, model)

    def step(self):
        pass  

class TrashAgent(Agent): 
    """
    Trash agent. 
    It appears randomly in the grid and also can be deleted if a roomba agent moves to its possition. 
    Attributes:
        unique_id: Agent's ID 
        direction: Randomly chosen direction chosen from one of eight directions
    """
    def __init__(self, unique_id, model):
        """
        Creates a new random trash agent.
        Args:
            unique_id: The agent's ID
            model: Model reference for the agent
        """
        super().__init__(unique_id, model) #calls the builder from Agent class to create agents in the model

    def step(self):
        pass  

