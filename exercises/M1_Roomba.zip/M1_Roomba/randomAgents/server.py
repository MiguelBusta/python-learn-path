"""
M1 Actividad Roomba
Miguel Ángel Bustamante Pérez A01781583
Juan Muniain Otero A01781341

14/11/2022
"""
from model import RandomModel, ObstacleAgent, TrashAgent
from mesa.visualization.modules import CanvasGrid, BarChartModule
from mesa.visualization.ModularVisualization import ModularServer
from mesa.visualization.UserParam import UserSettableParameter

def agent_portrayal(agent): #function to define the agents 
    if agent is None: return
    
    #dictionary that defines the agents properties 
    portrayal = {"Shape": "circle",
                 "Filled": "true",
                 "Layer": 0,
                 "Color": "red",
                 "r": 0.5}
    
    # function that receives an object and a class and returns True if that object is an instance of that class or a subclass of that class
    if(isinstance(agent, TrashAgent)):
        portrayal["Color"] = "purple"
        portrayal["Layer"] = "1"
        portrayal["r"] = 0.2 #radius of the agent
    
    if(isinstance(agent, ObstacleAgent)):
        portrayal["Color"] = "green"
        portrayal["Layer"] = "1"
        portrayal["r"] = 0.6 #radius of the agent

    return portrayal

#dictionary that includes the number of agents and also the dimensions of the grid 
# model_params = {"N":5, "width":10, "height":10} 

grid = CanvasGrid(agent_portrayal, 10, 10, 500, 500) #defining the values of the new grid object 
bar_chart = BarChartModule(
    [{"Label":"Steps", "Color":"#AA0000"}], 
    scope="agent", sorting="ascending", sort_by="Steps")  

server = ModularServer(RandomModel, [grid, bar_chart], "Random Agents", 
{
    "N":UserSettableParameter("slider", "Number of Roombas", 1, 1, 10, 1), #slider for number of roombas
    "width":10,
    "height":10,
    "trash_num":UserSettableParameter("slider", "Percentage of cells with trash", 1, 1, 100, 1), #slider for trash
    "time":UserSettableParameter("slider", "Steps to be computed", 1, 1, 150, 1) #slider for the number of steps
}) #creates the server with the model, the list with the grid properties, the title and also the parameters of the model (dict)
                       
server.port = 8521 # The default
server.launch()