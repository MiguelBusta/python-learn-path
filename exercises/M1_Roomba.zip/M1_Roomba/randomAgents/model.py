"""
M1 Actividad Roomba
Miguel Ángel Bustamante Pérez A01781583
Juan Muniain Otero A01781341

14/11/2022
"""

from mesa import Model, agent
from mesa.time import RandomActivation #in order to move any agent randomly 
from mesa.space import MultiGrid #allows multiple agent in each celd
from mesa.datacollection import DataCollector
from agent import RandomAgent, ObstacleAgent, TrashAgent


class RandomModel(Model):
    """ 
    Creates a new model with random agents.
    Args:
        N: Number of agents in the simulation
        height, width: The size of the grid to model
    """
    def __init__(self, N, width, height, trash_num, time):
        self.num_agents = N #defines the number of agents
        self.grid = MultiGrid(width,height,torus = False) #creates grid
        self.schedule = RandomActivation(self) # Activates the step in each agent, but the number of agent will be chosen randomly 
        self.running = True # this means that the simulation is running (True) or not (False) 

        self.datacollector = DataCollector( 
        agent_reporters={"Steps": lambda a: a.steps_taken if isinstance(a, RandomAgent) else 0}) #returns the data (basically the steps that have been done by the program, if the agent is part of the Random Agent class, return the steps if true, if not return 0) 

        #Attribute for trash
        self.ntrash = trash_num

        #Attribute for time steps
        self.time_steps = time

        self.placed_trash = 0

        # Creates the border of the grid
        border = [(x,y) for y in range(height) for x in range(width) if y in [0, height-1] or x in [0, width - 1]]

        # for every pos in the border 
        for pos in border: 
            obs = ObstacleAgent(pos, self) #creates an object type obstacleagent
            # self.schedule.add(obs)
            self.grid.place_agent(obs, pos) #places that object in the grid creating the limits 

        # Add the agent to a random empty grid cell
        for i in range(self.num_agents):
            a = RandomAgent(i+1000, self) #creates a roomba bot 
            self.schedule.add(a) #adds the roomba bot to the schedule

            # pos_gen = lambda w, h: (self.random.randrange(w), self.random.randrange(h)) #function that returns a random pos (w,h)  

            # pos = pos_gen(self.grid.width, self.grid.height) #generate a random inside the grid  

            # while (not self.grid.is_cell_empty(pos)): #while that cell is empty
            #     pos = pos_gen(self.grid.width, self.grid.height) #generate a random pos
            self.grid.place_agent(a, (1,1)) #adds the agent in that pos

        avaliable_cells = round(((self.ntrash / 100)*((width*height)-37)))
        self.placed_trash = avaliable_cells
        #For the trash agents 
        for i in range(avaliable_cells):
            a = TrashAgent("trash", self) #creates a trash agent 
            pos_gen = lambda w, h: (self.random.randrange(w), self.random.randrange(h)) #function that returns a random pos (w,h)
            pos = pos_gen(self.grid.width, self.grid.height) #generate a random inside the grid
            while (not self.grid.is_cell_empty(pos)): #while that cell is empty
                pos = pos_gen(self.grid.width, self.grid.height) #generate a random pos
            self.grid.place_agent(a, pos) #adds the agent in that pos
        
        
        self.datacollector.collect(self) #collect the data from the steps  

    def step(self):
        '''Advance the model by one step.'''
        self.schedule.step()
        self.datacollector.collect(self)

        #If the steps is equal to the steps from the slider 
        if self.schedule.steps == self.time_steps: 
            #end the simulation
            self.running = False 
            total_trash = 0
            for agent in self.schedule.agents:
                total_trash += agent.get_trash_collected()
                print(f"Trash collected: {total_trash}")
            clean_cells = (self.grid.width * self.grid.height) - 37 - (self.placed_trash - total_trash)
            grid_cells = (self.grid.width * self.grid.height) - 37
            print(f"Clean cells: {clean_cells} ({round(clean_cells * 100 / grid_cells)}%)")
            print(f"Trash collected: {total_trash} / {self.placed_trash} ({round(total_trash * 100 / self.placed_trash)}%)")